<?php
/**
 * Created by PhpStorm.
 * User: navin
 * Date: 12/12/2017
 * Time: 6:23 PM
 */
?>

<!-- Start Post -->
<div class="blog-post quote-post">
    <!-- Post Content -->
    <div class="post-content">
        <div class="post-type"><i class="fa fa-quote-left"></i></div>
        <div class="qoute-box">
            <a href="#">
                <h2>Throughout life people will make you mad, disrespect you and treat you bad. Let
                    God deal with the things they do, cause hate in your heart will consume you
                    too.</h2>
                <div class="qoute-author">John Kennedy</div>
            </a>
        </div>
        <ul class="post-meta">
            <li>By <a href="#">iThemesLab</a></li>
            <li>December 30, 2013</li>
            <li><a href="#">WordPress</a>, <a href="#">Graphic</a></li>
            <li><a href="#">4 Comments</a></li>
        </ul>
    </div>
</div>
<!-- End Post -->

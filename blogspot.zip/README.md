# Blog

<p align="center"><img src="https://blog.bufferapp.com/wp-content/uploads/2015/05/shareasimage-1.jpg"></p>

# Blogging site

## About Application

Blog is a site crated with the help of HTML, CSS, JavaScript & core PHP to share the thoughts and ideas between the friends and colleagues circle.
It will contain both technical and general experience we came accross and some interesting featured technologies related informations.
